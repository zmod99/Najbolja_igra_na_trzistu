package Calculator;

import java.util.Scanner;

public class Calc {
    public static void main(String[] args) {
        double a;
        double b;
        double rez;
        char oper;
        String unos;
        Scanner scanner = new Scanner(System.in);

        System.out.print("A: ");
        a = scanner.nextDouble();

        System.out.print("B: ");
        b = scanner.nextDouble();

        System.out.println("Operation: ( * / - + % ) -");

        unos = scanner.next();
        oper = unos.charAt(0);

        if (oper == '*') {
            rez = a * b;
            System.out.println("A * B = " + rez);

        } else if (oper == '/') {
            rez = a / b;
            System.out.println("A / B = " + rez);
        } else if (oper == '-') {
            rez = a / b;
            System.out.println("A / B = " + rez);
        } else if (oper == '+') {
            rez = a + b;
            System.out.println("A / B = " + rez);
        } else if (oper == '%') {
            rez = a % b;
            System.out.println("A / B = " + rez);
        } else {
            System.out.println("Wrong input");
        }
    }
}
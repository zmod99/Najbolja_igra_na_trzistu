
package Game;

import Game.Menu;

import java.util.Scanner;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        Avatar yourAvatar = new Avatar();
        Avatar wolf = new Avatar();
        wolf.agility = 5;
        wolf.defense = 5;
        wolf.damage = 18;
        wolf.health = 100;
        wolf.armor = 10;
        wolf.animal = "wolf";

        Avatar bear = new Avatar();
        bear.agility = 3;
        bear.defense = 6;
        bear.damage = 42;
        bear.health = 100;
        bear.armor = 30;
        bear.animal = "bear";

        Avatar lizard = new Avatar();
        lizard.agility = 11;
        lizard.defense = 2;
        lizard.damage = 3;
        lizard.health = 100;
        lizard.armor = 5;
        lizard.animal = "lizard";

        yourAvatar = Menu.showMenu1(wolf, bear, lizard); //sprema mi izabrani pick avatara
        Menu.showMenu3(yourAvatar, wolf, bear, lizard);
    }


}

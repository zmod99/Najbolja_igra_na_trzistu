package Game;

import java.math.*;

public class Fight {

    public static Avatar fightBear(Avatar yourAvatar, Avatar bear) {
        long previousTime = System.currentTimeMillis();
        double currentTime = 0;
        System.out.println("You are looking for your next prey as you are pacing through the forest...");
        while ((currentTime - previousTime < 1500)) {
            currentTime = System.currentTimeMillis();
        }
        System.out.println("You can smell your next pray as you hear something shushing..");

        while ((currentTime - previousTime < 3000)) {
            currentTime = System.currentTimeMillis();
        }
        System.out.println("You see a fucking bear that is looking at you and the combat begins !\n");
        while ((currentTime - previousTime < 5000)) {
            currentTime = System.currentTimeMillis();
        }
        while (yourAvatar.health > 0 && bear.health > 0) {
            previousTime = System.currentTimeMillis();
            int bearRandomAttack = (int) (Math.floor(Math.random() * 10)) + bear.agility - yourAvatar.defense;         // 0 - 10 + (0-10) agility
            int youRandomAttack = (int) (Math.floor(Math.random() * 10)) + yourAvatar.agility - bear.defense;
            if (bearRandomAttack > youRandomAttack) {
                System.out.printf("Bear smacks you(%s) across the face with his paws and damages you for %d\n\n", yourAvatar.animal, bear.damage);
                yourAvatar.health -= bear.damage;
            } else {
                System.out.printf("You(%s) pounce and slash the bear dealing %d damage\n\n", yourAvatar.animal, yourAvatar.damage);
                bear.health -= yourAvatar.damage;
            }
            while ((currentTime - previousTime < 1000)) {
                currentTime = System.currentTimeMillis();
            }
        }
        if (yourAvatar.health <= 0) {
            System.out.printf("The bear fucked you(%s) up\n", yourAvatar.animal);
            System.out.printf("The bear lives with %d health", bear.health);
            System.out.println("\n\n GAME OVER ");
            System.exit(1);
        } else {
            System.out.printf("You(%s) were the victorious one\n", yourAvatar.animal);
            System.out.printf("You are left with %d health\n", yourAvatar.health);
            System.out.println("You acquired 2 training points !\n");
            bear.health = 100;
            yourAvatar.trainPoints += 2;
        }
        return yourAvatar;
    }

    public static Avatar fightWolf(Avatar yourAvatar, Avatar wolf) {
        long previousTime = System.currentTimeMillis();
        double currentTime = 0;
        System.out.println("You are looking for your next prey as you are pacing through the forest...");
        while ((currentTime - previousTime < 1500)) {
            currentTime = System.currentTimeMillis();
        }
        System.out.println("You can smell your next pray as you hear something shushing..");

        while ((currentTime - previousTime < 3000)) {
            currentTime = System.currentTimeMillis();
        }
        System.out.println("You see a wolf preying up on you and the combat begins!\n");
        while ((currentTime - previousTime < 5000)) {
            currentTime = System.currentTimeMillis();
        }
        while (yourAvatar.health > 0 && wolf.health > 0) {
            previousTime = System.currentTimeMillis();
            int wolfRandomAttack = (int) (Math.floor(Math.random() * 10)) + wolf.agility - yourAvatar.defense;         // 0 - 10 + (0-10) agility
            int youRandomAttack = (int) (Math.floor(Math.random() * 10)) + yourAvatar.agility - wolf.defense;
            if (wolfRandomAttack > youRandomAttack) {
                System.out.printf("Wolf bites your(%s) face and damages you for %d\n\n", yourAvatar.animal, wolf.damage);
                yourAvatar.health -= wolf.damage;
            } else {
                System.out.printf("You(%s) pounce and slash the wolf dealing %d damage\n\n", yourAvatar.animal, yourAvatar.damage);
                wolf.health -= yourAvatar.damage;
            }
            while ((currentTime - previousTime < 1000)) {
                currentTime = System.currentTimeMillis();
            }
        }
        if (yourAvatar.health <= 0) {
            System.out.printf("The wolf fucked you(%s) up\n", yourAvatar.animal);
            System.out.printf("The wolf lives with %d health", wolf.health);
            System.out.println("\n\n GAME OVER ");
            System.exit(1);
        } else {
            System.out.printf("You(%s) were the victorious one\n", yourAvatar.animal);
            System.out.printf("You are left with %d health\n", yourAvatar.health);
            System.out.println("You acquired 1 training point !\n");
            wolf.health = 100;
            yourAvatar.trainPoints += 1;
        }
        return yourAvatar;

    }

    public static void fightLizard(Avatar yourAvatar, Avatar lizard) {
        long previousTime = System.currentTimeMillis();
        double currentTime = 0;
        System.out.println("You are looking for your next prey as you are pacing through the forest...");
        while ((currentTime - previousTime < 1500)) {
            currentTime = System.currentTimeMillis();
        }
        System.out.println("You can smell your next pray as you hear something shushing..");

        while ((currentTime - previousTime < 3000)) {
            currentTime = System.currentTimeMillis();
        }
        System.out.println("You see a lizard sneaking up on you and the combat begins!\n");
        while ((currentTime - previousTime < 5000)) {
            currentTime = System.currentTimeMillis();
        }
        while (yourAvatar.health > 0 && lizard.health > 0) {
            previousTime = System.currentTimeMillis();
            int lizardRandomAttack = (int) (Math.floor(Math.random() * 10)) + lizard.agility - yourAvatar.defense;         // 0 - 10 + (0-10) agility
            int youRandomAttack = (int) (Math.floor(Math.random() * 10)) + yourAvatar.agility - lizard.defense;
            if (lizardRandomAttack > youRandomAttack) {
                System.out.printf("Lizard slaps you (%s) across the face dealing %d damage\n\n", yourAvatar.animal, lizard.damage);
                yourAvatar.health -= lizard.damage;
            } else {
                System.out.printf("You(%s) pounce and stomp on lizard dealing %d damage\n\n", yourAvatar.animal, yourAvatar.damage);
                lizard.health -= yourAvatar.damage;
            }
            while ((currentTime - previousTime < 1000)) {
                currentTime = System.currentTimeMillis();
            }
        }
        if (yourAvatar.health <= 0) {
            System.out.printf("The lizard slapped you to death with his tail\n");
            System.out.printf("The lizard lives with %d health", lizard.health);
            System.out.println("\n\n GAME OVER ");
            System.exit(1);
        } else {
            System.out.printf("You(%s) were the victorious one\n", yourAvatar.animal);
            System.out.printf("You are left with %d health\n", yourAvatar.health);
            System.out.println("You acquired 1 training point !\n");
            yourAvatar.trainPoints += 1;
            lizard.health = 100;
        }

    }
}

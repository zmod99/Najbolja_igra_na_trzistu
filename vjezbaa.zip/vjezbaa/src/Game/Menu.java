package Game;

import java.util.Scanner;

import Game.Fight;

import java.math.*;

import java.io.IOException;

public class Menu {
    public static Avatar showMenu1(Avatar wolf, Avatar bear, Avatar lizard) {
        Scanner scanner = new Scanner(System.in);
        Avatar yourAvatar = new Avatar();
        System.out.println("Welcome to Forest Encounter v1 by zmod studios");
        System.out.print("A)Play game\nB)Credits\nC)Exit\n> ");
        switch (scanner.next().toUpperCase().charAt(0)) {

            case 'A':
                yourAvatar = showMenu2(wolf, bear, lizard);
                break;
            case 'B':
                long previousTime = System.currentTimeMillis();
                long currentTime = System.currentTimeMillis();
                System.out.print("Created ");
                while ((currentTime - previousTime) < 1000) {
                    currentTime = System.currentTimeMillis();
                }
                System.out.print("by ");
                while ((currentTime - previousTime) < 2000) {
                    currentTime = System.currentTimeMillis();
                }
                System.out.print("zmod ");

                while ((currentTime - previousTime) < 3000) {
                    currentTime = System.currentTimeMillis();
                }
                System.out.print("studios ");
                while ((currentTime - previousTime) < 4000) {
                    currentTime = System.currentTimeMillis();
                }
                System.out.print("- 2022\n\n");


                break;
            case 'C':
                System.exit(1);
                break;
            default:
                System.out.println("Wrong input");
                showMenu1(wolf, bear, lizard);
                break;
        }
        return yourAvatar;


    }

    public static Avatar showMenu2(Avatar wolf, Avatar bear, Avatar lizard) {
        boolean isEmpty = false;
        Avatar yourAvatar = new Avatar();
        Scanner scanner = new Scanner(System.in);
        System.out.print("Choose your animal:\nA)Indian Wolf\nB)Grizzly Bear\nC)Lizard\n> ");

        switch (scanner.next().toUpperCase().charAt(0)) {
            case 'A':
                System.out.println("You are now playing as a wolf!\n");
                yourAvatar.agility = wolf.agility;
                yourAvatar.defense = wolf.defense;
                yourAvatar.damage = wolf.damage;
                yourAvatar.health = wolf.health;
                yourAvatar.armor = wolf.armor;
                yourAvatar.animal = wolf.animal;
                break;
            case 'B':
                System.out.println("You are now playing as a Grizzly bear!\n");
                yourAvatar.agility = bear.agility;
                yourAvatar.defense = bear.defense;
                yourAvatar.damage = bear.damage;
                yourAvatar.health = bear.health;
                yourAvatar.armor = bear.armor;
                yourAvatar.animal = bear.animal;
                break;
            case 'C':
                System.out.println("You are now playing as a lizard!\n");
                yourAvatar.agility = lizard.agility;
                yourAvatar.defense = lizard.defense;
                yourAvatar.damage = lizard.damage;
                yourAvatar.health = lizard.health;
                yourAvatar.armor = lizard.armor;
                yourAvatar.animal = lizard.animal;
                break;
            default:
                System.out.println("Wrong input");
                isEmpty = true;

        }
        if (isEmpty) {
            yourAvatar = showMenu2(wolf, bear, lizard);
            isEmpty = false;
        }
        return yourAvatar;

    }

    public static void showMenu3(Avatar yourAvatar, Avatar wolf, Avatar bear, Avatar lizard) {
        Scanner scanner = new Scanner(System.in);
        int n = (int) (Math.floor(Math.random() * 5));
        System.out.println("A)Roam the jungle & fight\nB)Train\nC)Show stats\nD)Healing Grounds");
        switch (scanner.next().toUpperCase().charAt(0)) {
            case 'A':
                if (n >= 4) {
                    Game.Fight.fightBear(yourAvatar, bear);
                    break;
                } else if (n > 2) {
                    Game.Fight.fightWolf(yourAvatar, wolf);
                    break;
                } else {
                    Game.Fight.fightLizard(yourAvatar, lizard);
                    break;
                }
            case 'B':
                if (yourAvatar.trainPoints > 0) {
                    System.out.println("Put a point in:\nA)Agility\nB)Defense\nC)Damage\nD)Armor");
                    switch (scanner.next().toUpperCase().charAt(0)) {
                        case 'A':
                            System.out.print("You have put a point in agility\n");
                            yourAvatar.agility += 1;
                            yourAvatar.trainPoints -= 1;
                            break;
                        case 'B':
                            System.out.print("You have put a point in Defense\n");
                            yourAvatar.defense += 1;
                            yourAvatar.trainPoints -= 1;
                            break;
                        case 'C':
                            System.out.print("You have +1 damage per attack \n");
                            yourAvatar.damage += 1;
                            yourAvatar.trainPoints -= 1;
                            break;
                        default:
                            System.out.println("Wrong input");
                            break;

                    }
                } else {
                    System.out.println("You have 0 training points. Gain points by mauling animals in the jungle\n");
                }
                break;
            case 'C':
                System.out.println("Your stats : ");
                System.out.println("\nyou are playing as " + yourAvatar.animal.toUpperCase() + "\n");
                System.out.println("Health:" + yourAvatar.health);
                System.out.println("Agility:" + yourAvatar.agility);
                System.out.println("Defense:" + yourAvatar.defense);
                System.out.println("Damage:" + yourAvatar.damage);
                System.out.println("Armor:" + yourAvatar.armor);
                System.out.println("> ");
                break;
            case 'D':
                System.out.println("You have entered healing grounds\n\nYou regenerate 2 health per second\n\nHealing takes time...\n");
                long previousTime = System.currentTimeMillis();
                long currentTime = 0;
                int healed;
                if (scanner.hasNext()) {
                    currentTime = System.currentTimeMillis();
                }
                healed = (int) ((currentTime - previousTime) / 1000);
                healed *= 2;
                yourAvatar.health += healed;
                System.out.printf("You healed for %d and now your health is %d/100", healed, yourAvatar.health);
                System.out.println();
                break;

            default:
                break;
        }
        showMenu3(yourAvatar, wolf, bear, lizard);

    }

}

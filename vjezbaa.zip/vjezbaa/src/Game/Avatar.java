package Game;

public class Avatar {
    int damage;                    // 0 - 100
    int defense;                    // 0 - 100
    int health;                    // 0 - 999
    int armor;                    //  0 - 100 ( % )

    int agility;               // 0 - 10

    int trainPoints;
    String animal;
}

package Students;

import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int sum = 0;
        int n;
        int ocj1 = 0;
        int ocj2 = 0;
        int ocj3 = 0;
        int ocj4 = 0;
        int ocj5 = 0;
        int nisuProsli = 0;

        System.out.println("Unesite broj studenata");
        n = scanner.nextInt();
        for (int i = 0; i < n; i++) {
            System.out.println("Unesite ocjenu" + (i + 1) + ". studenta:");
            int ocj = scanner.nextInt();
            sum += ocj;
            if (ocj == 1) {
                ocj1++;
                nisuProsli++;

            } else if (ocj == 2) {
                ocj2++;
            } else if (ocj == 3) {
                ocj3++;
            } else if (ocj == 4) {
                ocj4++;
            } else {
                ocj5++;
            }
        }
        float prosjek = (float) sum / n;
        System.out.printf("\nProsjek ocjena:%.1f", prosjek);
        if (prosjek > 4.5) {
            System.out.println("\nUspjeh:ODLIČAN");
        } else if (prosjek > 3.5) {
            System.out.println("Uspjeh:VRLO DOBAR");
        } else if (prosjek > 2.5) {
            System.out.println("Uspjeh:DOBAR");
        } else if (prosjek > 1.5) {
            System.out.println("Uspjeh:DOVOLJAN");
        } else {
            System.out.println("Uspjeh:NEDOVOLJAN");
        }

        System.out.println("Nedovoljnih:" + ocj1);
        System.out.println("Dovoljnih:" + ocj2);
        System.out.println("Dobrih:" + ocj3);
        System.out.println("Vrlo dobrih:" + ocj4);
        System.out.println("Odličnih:" + ocj5);
        System.out.print("Postotak prolaznosti:");
        if (nisuProsli == 0) {
            System.out.print("100%");
        } else {
            System.out.printf("Postotak prolaznosti:%.2f%%",  ((float)(n - nisuProsli) / n * 100));
            ;
        }


    }
}